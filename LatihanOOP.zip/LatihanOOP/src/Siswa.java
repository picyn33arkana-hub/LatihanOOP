public class Siswa {
    
    String nama;
    int umur;

    public Siswa(String nama, int umur) {
        this.nama = nama;
        this.umur = umur;
    }

    @Override
    public String toString() {
        return "Nama: " + nama + ", Umur: " + umur;
    }
}
