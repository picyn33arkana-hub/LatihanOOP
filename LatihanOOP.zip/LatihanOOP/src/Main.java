public class Main {

    public static void main(String[] args) {

        Siswa siswa1 = new Siswa("Arkana", 16);
        Siswa siswa2 = new Siswa("Budi", 17);
        Siswa siswa3 = new Siswa("Andi", 16);

        System.out.println(siswa1);
        System.out.println(siswa2);
        System.out.println(siswa3);

        System.out.println(siswa1 == siswa2);
    }
}